#ifndef QUEUE_H
#define QUEUE_H

#include "pcb.h"

typedef struct {
    PCB_t *head;
    PCB_t *tail;
} PCB_Q_t;

extern PCB_Q_t Ready_q;

void q_init(PCB_Q_t *q);
void q_enqueue(PCB_Q_t *q, PCB_t *pcb);
PCB_t *q_dequeue(PCB_Q_t *q);

#endif
